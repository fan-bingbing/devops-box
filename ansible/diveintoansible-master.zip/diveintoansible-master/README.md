## Dive Into Ansible Course Code Repository

Repository with content for DiveInto.com's 'Dive Into Ansible' course

The related lab repository is available at - https://github.com/spurin/diveintoansible-lab

At present the course is available on Udemy at [https://www.udemy.com/course/diveintoansible](https://www.udemy.com/course/diveintoansible/?referralCode=28BBB7A1DCCD01BBA51F) and will be published by Packt on other platforms like O'Reilly towards the end of December 2020 or January 2021.

If you experience any problems with the course, or within this repository please reach out to me direct, James Spurin, or flag an issue in the repository.

![DiveIntoAnsible Cover](DiveIntoAnsible_Cover.png?raw=true "Dive Into Ansible")
